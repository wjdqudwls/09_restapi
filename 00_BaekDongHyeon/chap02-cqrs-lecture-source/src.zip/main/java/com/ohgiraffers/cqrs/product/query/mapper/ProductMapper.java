package com.ohgiraffers.cqrs.product.query.mapper;

import com.ohgiraffers.cqrs.product.query.dto.response.ProductDTO;

public interface ProductMapper {

  /* 상품 코드로 상품 상세 조회 */
  ProductDTO selectProductByCode(Long productCode);



}

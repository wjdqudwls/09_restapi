package com.ohgiraffers.cqrs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap02CqrsLectureSourceApplication {

  public static void main(String[] args) {
    SpringApplication.run(Chap02CqrsLectureSourceApplication.class, args);
  }

}
